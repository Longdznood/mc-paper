#!/bin/bash
java -Xms512M -Xmx1024M -jar server.jar nogui